
import './style.css'
import { supabase } from './supabase.js'

// Тауарлар Supabase базасынан жүктеледі
let products = []
let cart = []

// Бағаны форматтау
const formatPrice = price =>
  new Intl.NumberFormat('kk-KZ').format(Number(price)) + ' ₸'

// Категорияға сәйкес белгіше
function getIcon(category) {
  const icons = {
    'Ноутбуктер': '💻',
    'Смартфондар': '📱',
    'Құлаққаптар': '🎧',
    'Сағаттар': '⌚',
    'Планшеттер': '📟'
  }

  return icons[category] || '📦'
}

// HTML мәтінін қауіпсіз көрсету
function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[char])
}

// Тауарларды экранға шығару
function renderProducts(items) {
  const container = document.querySelector('#products')

  if (!items.length) {
    container.innerHTML = '<p>Тауар табылмады.</p>'
    return
  }

  container.innerHTML = items.map(product => `
    <article class="product-card">
      <div class="product-image">
        ${getIcon(product.category)}
      </div>

      <span class="category">
        ${escapeHTML(product.category)}
      </span>

      <h3>${escapeHTML(product.name)}</h3>

      <p>${escapeHTML(product.description)}</p>

      <div class="product-bottom">
        <strong>${formatPrice(product.price)}</strong>
        <button class="add-btn" data-id="${product.id}">
          + Себетке
        </button>
      </div>
    </article>
  `).join('')
}

// Себетті жаңарту
function updateCart() {
  document.querySelector('#cart-count').textContent = cart.length

  document.querySelector('#cart-total').textContent =
    formatPrice(
      cart.reduce((sum, item) => sum + Number(item.price), 0)
    )
}

// Supabase базасынан тауарларды алу
async function loadProducts() {
  const container = document.querySelector('#products')

  container.innerHTML = '<p>Тауарлар жүктелуде...</p>'

  const { data, error } = await supabase
    .from('products')
    .select('id, name, category, price, description, stock')
    .order('id', { ascending: true })

  if (error) {
    console.error('Supabase қатесі:', error)
    container.innerHTML =
      '<p>Тауарларды жүктеу мүмкін болмады. Қосылуды тексеріңіз.</p>'
    return
  }

  products = data || []

  renderProducts(products)
}

// Себетке тауар қосу
document.querySelector('#products').addEventListener('click', event => {
  const button = event.target.closest('.add-btn')

  if (!button) return

  const product = products.find(
    p => p.id === Number(button.dataset.id)
  )

  if (product) {
    cart.push(product)
    updateCart()
  }
})

// Тауарларды іздеу
document.querySelector('#search').addEventListener('input', event => {
  const query = event.target.value.toLowerCase().trim()

  const filteredProducts = products.filter(product =>
    (product.name + ' ' + product.category)
      .toLowerCase()
      .includes(query)
  )

  renderProducts(filteredProducts)
})

// Себетті ашу
document.querySelector('#cart-button').addEventListener('click', () => {
  const total = cart.reduce(
    (sum, product) => sum + Number(product.price), 0
  )

  alert(
    cart.length
      ? `Себетте ${cart.length} тауар бар.\nЖалпы: ${formatPrice(total)}`
      : 'Себет әзірге бос.'
  )
})

// Бастапқы іске қосу
updateCart()
loadProducts()
